export {updateView}
import { Viewport,State,blockState} from "./type";
import { attr ,isNotNullOrUndefined} from "./util";

function updateView(onFinish: () => void) {
    return function (s: State):void {
    
// Canvas elements
const svg = document.querySelector("#svgCanvas") as SVGGraphicsElement &
HTMLElement;
const preview = document.querySelector("#svgPreview") as SVGGraphicsElement &
HTMLElement;
const gameover = document.querySelector("#gameOver") as SVGGraphicsElement &
HTMLElement;
const container = document.querySelector("#main") as HTMLElement;

svg.setAttribute("height", `${Viewport.CANVAS_HEIGHT}`);
svg.setAttribute("width", `${Viewport.CANVAS_WIDTH}`);
preview.setAttribute("height", `${Viewport.PREVIEW_HEIGHT}`);
preview.setAttribute("width", `${Viewport.PREVIEW_WIDTH}`);

// Text fields
const levelText = document.querySelector("#levelText") as HTMLElement;
const scoreText = document.querySelector("#scoreText") as HTMLElement;
const highScoreText = document.querySelector("#highScoreText") as HTMLElement;
const poweruptext = document.querySelector("#powerupsText") as HTMLElement;
// show the text on the canvas
levelText.innerText = String(s.level);
scoreText.innerText = String(s.score);
highScoreText.innerText = String(s.highscore);
poweruptext.innerText = String(s.powerup)

/** Rendering (side effects) */

/**
 * Displays a SVG element on the canvas. Brings to foreground.
 * @param elem SVG element to display
 */
const show = (elem: SVGGraphicsElement) => {
    elem.setAttribute("visibility", "visible");
    elem.parentNode!.appendChild(elem);};
  
  /**
   * Hides a SVG element on the canvas.
   * @param elem SVG element to hide
   */
  const hide = (elem: SVGGraphicsElement) =>
    elem.setAttribute("visibility", "hidden");
  
  /**
   * Creates an SVG element with the given properties.
   *
   * See https://developer.mozilla.org/en-US/docs/Web/SVG/Element for valid
   * element names and properties.
   *
   * @param namespace Namespace of the SVG element
   * @param name SVGElement name
   * @param props Properties to set on the SVG element
   * @returns SVG element
   */
  const createSvgElement = (
    namespace: string | null,
    name: string,
    props: Record<string, string> = {}
  ) => {
    const elem = document.createElementNS(namespace, name) as SVGElement;
    Object.entries(props).forEach(([k, v]) => elem.setAttribute(k, v));
    return elem;};

  // function to create the block
const uploadblock = (num:string,height:string,width:string ,x:string,y:string,style:string) => (namespace: SVGGraphicsElement &
    HTMLElement) => {const b = createSvgElement(namespace.namespaceURI,"rect",{id:num,height:height,width:width,x:x,y:y,style:style});
    namespace.appendChild(b); return b}

// function to show the blocks 
const renderpreviewblock = (b:blockState) => {const v = document.getElementById(b.id) || uploadblock(b.id,b.height,b.width,b.x,b.y,b.style)(preview);
  attr(v,{x:b.x,y:b.y});}
const renderusedblock = (b:blockState) => {const v = document.getElementById(b.id) || uploadblock(b.id,b.height,b.width,b.x,b.y,b.style)(svg);
  attr(v,{x:b.x,y:b.y});}
const rendercurrentblock = (b:blockState) =>  {const v = document.getElementById(b.id) || uploadblock(b.id,b.height,b.width,b.x,b.y,b.style)(svg);
  attr(v,{x:b.x,y:b.y});}

  // dont show preview after level 2 to increase difficulty
  if (s.level<=2){s.blocks.next.forEach(renderpreviewblock)}

  // show or un-show the blocks on the window
  s.blocks.current.forEach(rendercurrentblock)
  s.blocks.used.forEach(renderusedblock)
  s.blocks.exitnext.map(o => document.getElementById(o.id))
  .filter(isNotNullOrUndefined)
  .forEach(v => {try {preview.removeChild(v)} catch (e) {}})
  
  s.blocks.exitcurrent.map(o => document.getElementById(o.id))
  .filter(isNotNullOrUndefined)
  .forEach(v => {try {svg.removeChild(v)} catch (e) {}})

  s.blocks.exitused.map(o => document.getElementById(o.id))
  .filter(isNotNullOrUndefined)
  .forEach(v => {try {svg.removeChild(v)} catch (e) {}})
  
      if (s.gameEnd) {
        show(gameover);
      } else {hide(gameover);}}}