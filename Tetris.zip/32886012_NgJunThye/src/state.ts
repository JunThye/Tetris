export {initialState,tick,reduceState,Tick,Move,Restart,Rotate,PowerUp}
import { State,Action, blockState,Block,blocktype,rowNumbers} from "./type";
import { RNG} from "./util";

const initialState: State = {
  gameEnd: false,
  numberofblocks: 0,
  score:0,
  level:1,
  highscore:0,
  powerup:1,
  blocks: {
      next: [],
      current: [],
      used : [],
      exitnext:[],
      exitcurrent:[],
      exitused:[],
     
  }
} as const;

/**
 * Updates the state by proceeding with one time step.
 *
 * @param s Current state
 * @returns Updated state
 */
const tick = (s: State) => s;

const reduceState = (s: State, action: Action) => action.apply(s);

class Tick implements Action {
  constructor(public readonly x:number) {}    
  apply (s:State):State{
    // check if any block is at y==0 and cant move
    const end = s.blocks.used.map((block) => parseFloat(block.y) == 0 )
    if (end.includes(true)){return {...s,gameEnd:true}}
    // check any rows to clear
    // filter rows 10 blocks
    const row = rowNumbers.map((num) => s.blocks.used.filter((blocks) => parseFloat(blocks.y) == num*20)).filter((arr) => arr.length==10)
    if (row.length!= 0){

      // put all arrays into one array
      const flattenedArray = row.reduce((acc, arr) => acc.concat(arr), []);

      // put them into exitused, and remove from used
      const addtoexit = s.blocks.exitused.concat(flattenedArray)
      const filter = s.blocks.used.filter((blocks) => !addtoexit.includes(blocks))

      // seperate into different arrays for different rows
      const check_drop_after_filter = rowNumbers.map((num) => filter.filter((blocks) => parseFloat(blocks.y) == num*20) )

      // check from bottom rows and change their y 
      const updatedState = check_drop_after_filter.reduceRight((accState:State, blocks) => {
        const filteredstate = {...accState,
            blocks:{
              ...accState.blocks,
              used: accState.blocks.used.filter((block) => !blocks.includes(block))}}

        /// to check how many lines it can go down
        const fourrow = changeblocks(filteredstate)(blocks,0,80)
        const threerow = changeblocks(filteredstate)(blocks,0,60)
        const tworow = changeblocks(filteredstate)(blocks,0,40)
        const onerow = changeblocks(filteredstate)(blocks,0,20)
        const combine = (fourrow != blocks)? fourrow: (threerow!=blocks)? threerow: (tworow!=blocks)? tworow:onerow

        // add finalised row to return 
        return{
        ...accState,
        blocks:{
          ...accState.blocks,
          used: accState.blocks.used.filter((block) => !blocks.includes(block)).concat(combine)
        }}
      }, {...s,
        blocks:{
          ...s.blocks,
          exitused:addtoexit,
          used: filter,
        }});

      // return final state where level and score is calculated when rows are cleared
      return {...s,
      level: (Math.floor((s.score + 10 + row.length)/10)),
      score:s.score + row.length,
      highscore: (s.highscore>=s.score + row.length)? (s.highscore) : (s.score + row.length),
      blocks:{
        ...s.blocks,
        exitused:addtoexit,
        used: updatedState.blocks.used,
      }}}

      // check if the block can still go down
    const nextdrop = s.blocks.current.map((block) => check_possible_ud(s)(block,20))
    if (nextdrop.includes(false)){
        return {...s,
        blocks:{
          ...s.blocks,
          used: s.blocks.used.concat(s.blocks.current),
          current : []
        }}}

    // make next block
    if (s.blocks.next.length === 0){
      return Tick.next_empty(s,this.x)}

    // move next block to current to be controlled
    if (s.blocks.current.length === 0) {
        return Tick.current_empty(s)}
    else {return s}}

  /// FUNCTION TO CREATE DIFFERENT TYPE OF TETRIS BLOCK
  static createBlocks = (type:string) => (s:State)=> {
    if (type == "L"){
      const a = addBlock("next")(s)(createCube(String(s.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,"0","0","fill: orange","L"))
      const b = addBlock("next")(a)(createCube(String(a.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH}`,"0","fill: orange","L"))
      const c = addBlock("next")(b)(createCube(String(b.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH*2}`,"0","fill: orange","L"))
      const d = addBlock("next")(c)(createCube(String(c.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,"0",`${Block.HEIGHT}`,"fill: orange","L"))
      return d}
    if (type == "I"){
      const a = addBlock("next")(s)(createCube(String(s.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,"0","0","fill: cyan","I"))
      const b = addBlock("next")(a)(createCube(String(a.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH}`,"0","fill: cyan","I"))
      const c = addBlock("next")(b)(createCube(String(b.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH*2}`,"0","fill: cyan","I"))
      const d = addBlock("next")(c)(createCube(String(c.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH*3}`,"0","fill: cyan","I"))
      return d} 
    if (type == "J"){
      const a = addBlock("next")(s)(createCube(String(s.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,"0","0","fill: blue","J"))
      const b = addBlock("next")(a)(createCube(String(a.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH}`,"0","fill: blue","J"))
      const c = addBlock("next")(b)(createCube(String(b.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH*2}`,"0","fill: blue","J"))
      const d = addBlock("next")(c)(createCube(String(c.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH*2}`,`${Block.HEIGHT}`,"fill: blue","J"))
      return d}
    if (type == "O"){
      const a = addBlock("next")(s)(createCube(String(s.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,"0","0","fill: yellow","O"))
      const b = addBlock("next")(a)(createCube(String(a.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH}`,"0","fill: yellow","O"))
      const c = addBlock("next")(b)(createCube(String(b.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH}`,`${Block.HEIGHT}`,"fill: yellow","O"))
      const d = addBlock("next")(c)(createCube(String(c.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,"0",`${Block.HEIGHT}`,"fill: yellow","O"))
      return d}
    if (type == "T"){
      const a = addBlock("next")(s)(createCube(String(s.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,"0","0","fill: pink","T"))
      const b = addBlock("next")(a)(createCube(String(a.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH}`,"0","fill: pink","T"))
      const c = addBlock("next")(b)(createCube(String(b.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH*2}`,"0","fill: pink","T"))
      const d = addBlock("next")(c)(createCube(String(c.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH}`,`${Block.HEIGHT}`,"fill: pink","T"))
      return d}
    if (type == "S"){
      const a = addBlock("next")(s)(createCube(String(s.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH*2}`,"0","fill: green","S"))
      const b = addBlock("next")(a)(createCube(String(a.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH}`,"0","fill: green","S"))
      const c = addBlock("next")(b)(createCube(String(b.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,"0",`${Block.HEIGHT}`,"fill: green","S"))
      const d = addBlock("next")(c)(createCube(String(c.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH}`,`${Block.HEIGHT}`,"fill: green","S"))
      return d}
    if (type == "Z"){
      const a = addBlock("next")(s)(createCube(String(s.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,"0","0","fill: red","Z"))
      const b = addBlock("next")(a)(createCube(String(a.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH}`,"0","fill: red","Z"))
      const c = addBlock("next")(b)(createCube(String(b.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH}`,`${Block.HEIGHT}`,"fill: red","Z"))
      const d = addBlock("next")(c)(createCube(String(c.numberofblocks),`${Block.HEIGHT}`,`${Block.WIDTH}`,`${Block.WIDTH*2}`,`${Block.HEIGHT}`,"fill: red","Z"))
      return d}}

  // function to deal with no blocks in current, move blocks in next to current
  static current_empty = (s:State) => {
    const to_current = s.blocks.next.slice(0,4)
    const currentBlock = to_current.reduce((acc, block) => addBlock("current")(acc)(block), s);
    const filteredNextBlocks = s.blocks.next.filter(nextBlock => !to_current.includes(nextBlock));
    
    return {...s,
    numberofblocks:s.numberofblocks,
  blocks: {
  ...s.blocks,
  current: currentBlock.blocks.current,
  next: filteredNextBlocks,
  exitnext: currentBlock.blocks.current}}}

// function to make new block for next block
  static next_empty =(s:State,x:number) => {

    // use the tick time to create
    const scaled = RNG.scale(RNG.hash(x))
      const type = blocktype[scaled]
      const addnextblock = Tick.createBlocks(type)(s)
      if (addnextblock)return {
        ...s,
        numberofblocks:addnextblock.numberofblocks,
        blocks: {...s.blocks,
        next:addnextblock.blocks.next}}
      return s
  }
}

// move class, changes x,y of blocks 
class Move implements Action{
  constructor (public readonly x_value: number,public readonly y_value:number){}
  apply = (s:State):State =>{  
    return {...s,
    blocks:{
      ...s.blocks,
      current:  changeblocks(s)(s.blocks.current,this.x_value,this.y_value)
    }}}}

// restart class, clear everything to allow user to restart game
class Restart implements Action{
  constructor () {}
  apply = (s:State): State => {
    const newstate = initialState;
    return {
      ...newstate,
      numberofblocks:s.numberofblocks,
      highscore:s.highscore,
      blocks:{
        ...newstate.blocks,
        exitcurrent: s.blocks.current,
        exitused: s.blocks.used,
        exitnext: s.blocks.next
      }}}}
  
// rotate class to rotate current blocks
class Rotate implements Action{
  constructor (){}
  apply = (s:State):State => {
    // get the type of the block
    const typearray = s.blocks.current.map(block => block.type)
    const blocks = s.blocks.current

    // middle point of the tetromino, dont change
    const middle = blocks[1]

    // get the remaining 3 block by id
    const filltered = s.blocks.current.filter((block) => block!= middle)
    const first = blocks.filter((block) => block.id == String(parseFloat(middle.id)-1))
    const second = blocks.filter((block) => block.id == String(parseFloat(middle.id)+1))
    const third =blocks.filter((block) => block.id == String(parseFloat(middle.id)+2))
    if (blocks.length==0){
      return s
    }

    // rotates the blocks based on its type
    if (typearray.includes("O")){
      return s
    }
    else if (typearray.includes("I")){
      /// rotate the block and implement wall kick if needed
      const first = filltered.filter((block) => ((block.y == middle.y) && (block.x==String(parseFloat(middle.x) -20)) || (block.x == middle.x) && (String(parseFloat(block.y) -20)==middle.y) ))
      .map((block) => (block.y == middle.y) && (block.x==String(parseFloat(middle.x) -20))? {...block,y:String(parseFloat(middle.y) +20),x:middle.x} : {...block,x:String(parseFloat(middle.x) -20),y:middle.y})
      const second = filltered.filter((block) => ((block.y == middle.y) && (block.x==String(parseFloat(middle.x) +20)) || (block.x == middle.x) && (String(parseFloat(block.y) +20)==middle.y) ))
      .map((block) => (block.y == middle.y) && (block.x==String(parseFloat(middle.x) +20))? {...block,y:String(parseFloat(middle.y) -20),x:middle.x} :{...block,x:String(parseFloat(middle.x) +20),y:middle.y})
      const third = filltered.filter((block) => ((block.y == middle.y) && (block.x==String(parseFloat(middle.x) +40)) || (block.x == middle.x) && (String(parseFloat(block.y) +40) ==middle.y) ))
      .map((block) => (block.y == middle.y) && (block.x==String(parseFloat(middle.x) +40))? {...block,y:String(parseFloat(middle.y) -40),x:middle.x} : {...block,x:String(parseFloat(middle.x) +40),y:middle.y})
      const combined = [first[0],middle,second[0],third[0]]
      return check_need_for_wallkick(s,combined,blocks)
    }
    else if (typearray.includes("S")){
       /// rotate the block and implement wall kick if needed
      const firstblock = first.map((block) => right(middle,block)?{...block,x:middle.x , y:String(parseFloat(middle.y)+20)}:{...block,y:middle.y , x:String(parseFloat(middle.x)+20)} )
      const secondblock = second.map((block) => leftdown(middle,block)?{...block, y:String(parseFloat(block.y)-40)}:{...block,y:String(parseFloat(block.y)+40)} )
      const thirdblock = third.map((block) => left(middle,block)?{...block,x:middle.x , y:String(parseFloat(middle.y)+20)}:{...block,y:middle.y , x:String(parseFloat(middle.x)-20)} )
      const combined = [firstblock[0],middle,secondblock[0],thirdblock[0]]
      return check_need_for_wallkick(s,combined,blocks)
    }
    else if (typearray.includes("Z")){
       /// rotate the block and implement wall kick if needed
      const firstblock = first.map((block) => left(middle,block)?{...block,x:middle.x , y:String(parseFloat(middle.y)-20)}:{...block,y:middle.y , x:String(parseFloat(middle.x)-20)} )
      const secondblock = second.map((block) => left(middle,block)?{...block,x:middle.x , y:String(parseFloat(middle.y)+20)}:{...block,y:middle.y , x:String(parseFloat(middle.x)-20)} )
      const thirdblock = third.map((block) => leftdown(middle,block)?{...block, x:String(parseFloat(block.x)+40)}:{...block,x:String(parseFloat(block.x)-40)} )
      const combined = [firstblock[0],middle,secondblock[0],thirdblock[0]]
      return check_need_for_wallkick(s,combined,blocks)
    }
    else{
      /// rotate the block and implement wall kick if needed
      const rotation = filltered.map((block) => left(middle,block)?
      {...block,x:middle.x,y:String(parseFloat(middle.y)-20)}:right(middle,block)?
      {...block,x:middle.x,y:String(parseFloat(middle.y)+20)}:up(middle,block)?
      {...block,y:middle.y,x:String(parseFloat(middle.x)+20)}: down(middle,block)?
      {...block,y:middle.y,x:String(parseFloat(middle.x)-20)}:leftdown(middle,block)? 
      {...block,y:String(parseFloat(block.y)-40)}:leftup(middle,block)? 
      {...block,x:String(parseFloat(block.x)+40)}:rightup(middle,block)? 
      {...block,y:String(parseFloat(block.y)+40)}:{...block,x:String(parseFloat(block.x)-40)})
      const combine = rotation.concat(middle)
      const combined = combine.slice().sort((a,b) => parseFloat(a.id) - parseFloat(b.id) )
      return check_need_for_wallkick(s,combined,blocks)
      }}}
    
  // power class, implement the powerup of clearing whole canvas but only used once
  class PowerUp implements Action{
    constructor (){}
    apply = (s:State):State => {
      if(s.powerup == 0)return s
      if (s.gameEnd == true) return s
      return {...s,powerup:s.powerup-1,blocks:{
        ...s.blocks,
        used:[],
        exitused:s.blocks.exitused.concat(s.blocks.used)

      }}
  }}

    // function to create a cube return blockstate
    function createCube(n:string,height:string =`${Block.HEIGHT}`,width:string =`${Block.WIDTH}`,x:string = "0",y:string ="0",style:string = "fill: green",type:string) : blockState{
      return {
          id: n,
          height: height,
          width: width,
          x: x,
          y: y,
          style:style,
          type:type,
         
      }}

    /// ADD BLOCKS
    const addBlock = (location: keyof State["blocks"]) => (s:State) =>  (b:blockState):State => {
    
      return  {...s,
      numberofblocks: s.numberofblocks+1,
      blocks: {...s.blocks,
          [location]:[...s.blocks[location].concat(b)]}
          
    }}

/// FUNCTION USED FOR MOVEMENT

// change the x and y of the array of blocks
const changeblocks =(s:State) => (b:ReadonlyArray<blockState>,x_value:number,y_value:number)=> {
  const changable =  b.map((blocks) => check_possible_lr(s)(blocks,x_value) && check_possible_ud(s)(blocks,y_value))
  if (changable.includes(false))
  return b 
  else{return  b.map((blocks) => changexy(blocks,x_value,y_value))}
}

// change the block's x and y
const changexy =(b:blockState,x_value:number,y_value:number) => {
  return {...b,x:String(parseFloat(b.x)+x_value),y:String(parseFloat(b.y)+y_value)}
}

// check if can move left right
const check_possible_lr =(s:State) =>  (b:blockState | undefined,x_value:number):boolean =>{
  if (b == undefined) return false
  else{const collision = s.blocks.used.filter((block) => ((String(parseFloat(b.x)+x_value) == block.x) && (b.y == block.y)));
    if (((parseFloat(b.x)+x_value)<0) || ((parseFloat(b.x)+x_value)>180)|| collision.length!=0) {return false} return true}}

//check if can move up down
const check_possible_ud =(s:State) => (b:blockState | undefined,y_value:number):boolean =>{
  if (b == undefined) return false
  else{
    const collision = s.blocks.used.filter((block) => ((String(parseFloat(b.y)+y_value) == block.y) && (b.x == block.x)));
    if ( ((parseFloat(b.y)+y_value)<=380) && collision.length==0) {return true} else {return false}}}

// move blocks one block right or left
const one_right = (s:State,blocks:ReadonlyArray<blockState>) => changeblocks(s)(blocks,20,0)
const one_left = (s:State,blocks:ReadonlyArray<blockState>) => changeblocks(s)(blocks,-20,0)

/// FUNCTIONS TO CHECK LOCATION OF MIDDLE BLOCK
const left = (middle:blockState,block:blockState) =>{
  return (block.y == middle.y) && (block.x==String(parseFloat(middle.x) -20))
}
const right = (middle:blockState,block:blockState) =>{
  return (block.y == middle.y) && (block.x==String(parseFloat(middle.x) +20))
}
const up = (middle:blockState,block:blockState) =>{
  return (block.x == middle.x) && (block.y==String(parseFloat(middle.y) -20))
}
const down = (middle:blockState,block:blockState) =>{
  return (block.x == middle.x) && (block.y==String(parseFloat(middle.y) +20))
}
const leftdown = (middle:blockState,block:blockState) =>{
  return (block.y == String(parseFloat(middle.y) +20)) && (block.x==String(parseFloat(middle.x) -20))
}
const leftup = (middle:blockState,block:blockState) =>{
  return (block.y == String(parseFloat(middle.y) -20)) && (block.x==String(parseFloat(middle.x) -20))
}
const rightdown = (middle:blockState,block:blockState) =>{
  return (block.y == String(parseFloat(middle.y) +20)) && (block.x==String(parseFloat(middle.x) +20))
}
const rightup = (middle:blockState,block:blockState) =>{
  return (block.y == String(parseFloat(middle.y) -20)) && (block.x==String(parseFloat(middle.x) +20))
}

// function to check the block out or in the canvas
const checkoutside = (s:State,block:blockState) => {
  return check_possible_lr(s)(block,0) && check_possible_ud(s)(block,0)
}

//perform wall kick if possible
const wallkick = (s:State,arr:ReadonlyArray<blockState>,original:ReadonlyArray<blockState>) => {
  const final = one_right(s,arr) == arr? one_left(s,arr)==arr? original: one_left(s,arr):one_right(s,arr)
  return {...s,blocks:{...s.blocks,
    current:final}}

}
/// check if rotation will go out of borders, then if needed do wall kick, if still cant then dont rotate
const check_need_for_wallkick = (s:State,arr:ReadonlyArray<blockState>,original:ReadonlyArray<blockState>) => {
  const combined_check = arr.map((block) =>checkoutside(s,block) )
      if (combined_check.includes(false)){
        return wallkick(s,arr,original)}
      return {...s,blocks:{...s.blocks,
      current:arr}}
      }
