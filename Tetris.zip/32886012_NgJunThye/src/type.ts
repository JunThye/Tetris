export type {Key,Event,State,blockState,Action}
export {Viewport,Constants,Block,blocktype,rowNumbers}
/** Constants */

const Viewport = {
    CANVAS_WIDTH: 200,
    CANVAS_HEIGHT: 400,
    PREVIEW_WIDTH: 160,
    PREVIEW_HEIGHT: 80,
  } as const;

const Constants = {
    TICK_RATE_MS: 500,
    GRID_WIDTH: 10,
    GRID_HEIGHT: 20,
  } as const;

const Block = {
    WIDTH: Viewport.CANVAS_WIDTH / Constants.GRID_WIDTH,
    HEIGHT: Viewport.CANVAS_HEIGHT / Constants.GRID_HEIGHT,
  };
  
  /** User input */
  
  type Key = "KeyS" | "KeyA" | "KeyD" | "KeyR" |"KeyW" | "KeyP";
  
  type Event = "keydown" | "keyup" | "keypress";
  
  const numofRows = 20; // Number of rows
  // array for different rows
  const rowNumbers = Array.from({ length: numofRows }, (_, index) => index).map((num) => num+1);
  
  const blocktype:{[key: number]:string} = {1:"I", 2:"S", 3:"O" ,4:"Z",5:"J" , 6:"L" ,7:"T"}
  /** Utility functions */
  
  /** State processing */
// type for state and attributes of state
type State = Readonly<{
    gameEnd: boolean;
    numberofblocks : number,
    level :number,
    score:number,
    highscore: number,
    powerup: number,
    blocks: Readonly<blockArrays>
  }>;

type blockArrays = Readonly<{
    current:ReadonlyArray<blockState>,
    next:ReadonlyArray<blockState>,
    used:ReadonlyArray<blockState>,
    exitnext:ReadonlyArray<blockState>,
    exitcurrent:ReadonlyArray<blockState>,
    exitused:ReadonlyArray<blockState>,
}>

type blockState = Readonly<{
    id: string,
    height: string,
    width: string,
    x: string,
    y: string,
    style:string,
    type:string,
}>

interface Action {
    apply(s: State): State;
  }



