export {attr,RNG,isNotNullOrUndefined}
import { Observable,scan,map } from "rxjs";

/**RNG, attr, isNotNullOrUndefined all gotten from
 * source: asteroids code */ 

abstract class RNG {
    // LCG using GCC's constants
    private static m = 0x80000000; // 2**31
    private static a = 1103515245;
    private static c = 12345;

    /**
     * Call `hash` repeatedly to generate the sequence of hashes.
     * @param seed 
     * @returns a hash of the seed
     */
    public static hash = (seed: number) => (RNG.a * seed + RNG.c) % RNG.m;

    /**
 h    * Takes hash value and scales it to the range [-1, 1]
     */
    public static scale = (hash: number) => Math.ceil(Math.abs(((2 * hash) / (RNG.m - 1) - 1)*7));
}

const attr = (e: Element, o: { [p: string]: unknown }) => { for (const k in o) e.setAttribute(k, String(o[k])) }

function isNotNullOrUndefined<T extends object>(input: null | undefined | T): input is T {
    return input != null;
}